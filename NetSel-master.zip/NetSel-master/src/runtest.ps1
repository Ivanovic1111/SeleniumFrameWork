
param (
    [Parameter(Mandatory=$true)][String] $xunitConsole,
    [Parameter(Mandatory=$true)][String] $sourceDirectory
)
 
if (!(Test-Path $xunitConsole))
{
    throw "xunit.console.exe does not exist. Please check $xunitConsole file."
}
 
$assembliesToTest = (Get-ChildItem "$sourceDirectory" -Recurse -Include "*Test*.dll" -Exclude "*JavaScript*" -Name | Select-String "bin")
$report = (Get-ChildItem -Path "$sourceDirectory" -Name "reports")
 
$atLeastOneTestRun = $false
 
Write-Host "[Debug] ************* Running Unit Tests *************"
 
foreach ($testFile in $assembliesToTest) {
    Write-Host "[Debug] *************** Testing $testFile ***************"
 
  $fileNameOnly = Split-Path $testFile -Leaf
 
  $unitTestPath = Join-Path $sourceDirectory $report
   $unitTestFileName = Join-Path $unitTestPath ($fileNameOnly + "-XunitTestResult.xml")
   Write-Output $unitTestFileName
 
  $fullNameTestFile = Join-Path $sourceDirectory $testFile
  
  Write-Host "[Debug] *************** fullNameTestFile $fullNameTestFile"
 
  & $xunitConsole $fullNameTestFile -xml $unitTestFileName
  $atLeastOneTestRun = $true
}
 
if ($atLeastOneTestRun -eq $false) {
    Write-Output "Unit Tests didn't run!"
    exit(1)
}
