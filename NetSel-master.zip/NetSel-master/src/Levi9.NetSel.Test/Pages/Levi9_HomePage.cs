﻿using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System;

namespace Levi9.NetSel.Test.Pages
{
    class Levi9_HomePage :BasePage
    {
        public Levi9_HomePage(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }

        public By _logo = By.XPath("//img[@class='logo-levinine']");
       
        public IWebElement Logo()
        {
            return Driver.FindElement(_logo);
        }

        public IWebElement breadcrumb()
        {
            return Driver.FindElement(By.XPath("//div[@class= 'breadcrumb']//a[contains(@href,'about')]"));
        }

        //One plus one equals nine
        public IWebElement AboutUs() {
            return Driver.FindElement(By.XPath("//section[contains(@class, 'about-section')]//h4"));
        }

        public String GetAboutUs() {

            return AboutUs().Text;
        }
    }
}
