﻿using Levi9.NetSel.Elements;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace Levi9.NetSel.Test.Pages
{
    public class RandomDataGeneratorPage : BasePage
    {
        // Registration page objects
        private readonly By firstName = By.Id("name_3_firstname");
        private readonly By lastName = By.Id("name_3_lastname");
        private readonly By hobbyDance = By.XPath("//input[@value='dance']");
        private readonly By country = By.Id("dropdown_7");
        private readonly By phoneNumber = By.Id("phone_9");
        private readonly By dateMonth = By.Id("mm_date_8");
        private readonly By dateDay = By.Id("dd_date_8");
        private readonly By dateYear = By.Id("yy_date_8");
        private readonly By username = By.Id("username");
        private readonly By email = By.Id("email_1");
        private readonly By aboutYourself = By.Id("description");
        private readonly By password = By.Id("password_2");
        private readonly By confirmPassword = By.Id("confirm_password_password_2");
        private readonly By submit = By.XPath("//input[@value='Submit']");
        // Test data
        private static List<string> countryList = new List<string> { "Angola", "Australia", "Armenia" };
        private static List<string> testList = new List<string> { "WEB: ", "web: ", "Web: " };

        public RandomDataGeneratorPage(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }
        
        public class RegistrationPage
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Country { get; set; }
            public string PhoneNumber { get; set; }
            public string DateMonth { get; set; }
            public string DateDay { get; set; }
            public string DateYear { get; set; }
            public string Username { get; set; }
            public string Email { get; set; }
            public string AboutYourself { get; set; }
            public string Password { get; set; }
            public string ConfirmPassword { get; set; }
        }

        // Registration page First Name field
        private IWebElement GetFirstName()
        {
            var element = GetElement(firstName);
            return element;
        }

        public void SetFirstName(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, firstName, 1);
            InputElements inputElement = new InputElements(GetFirstName());
            inputElement.SendKeys(value);
        }

        // Registration page Last Name field
        private IWebElement GetLastName()
        {
            var element = GetElement(lastName);
            return element;
        }

        public void SetLastName(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, lastName, 1);
            InputElements inputElement = new InputElements(GetLastName());
            inputElement.SendKeys(value);
        }

        // Registration page Hobby checkbox Dance option
        private IWebElement GetHobbyDance()
        {
            var element = GetElement(hobbyDance);
            return element;
        }

        public void SetHobbyDance()
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, hobbyDance, 1);
            CheckBox checkBoxElement = new CheckBox(GetHobbyDance());
            checkBoxElement.SelectValue();
        }

        // Registration page Country dropdown
        private IWebElement GetCountry()
        {
            var element = GetElement(country);
            return element;
        }

        public void SetCountry(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, country, 1);
            SelectWebElement selectWebElement = new SelectWebElement(GetCountry());
            selectWebElement.SelectByValue(value);
        }

        // Registration page Phone Number field
        private IWebElement GetPhoneNumber()
        {
            var element = GetElement(phoneNumber);
            return element;
        }

        public void SetPhoneNumber(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, phoneNumber, 1);
            InputElements inputElement = new InputElements(GetPhoneNumber());
            inputElement.SendKeys(value);
        }

        // Registration page Date of Birth field Month dropdown
        private IWebElement GetDateMonth()
        {
            var element = GetElement(dateMonth);
            return element;
        }

        public void SetDateMonth(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, dateMonth, 1);
            SelectWebElement selectWebElement = new SelectWebElement(GetDateMonth());
            selectWebElement.SelectByValue(value);
        }

        // Registration page Date of Birth field Day dropdown
        private IWebElement GetDateDay()
        {
            var element = GetElement(dateDay);
            return element;
        }

        public void SetDateDay(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, dateDay, 1);
            SelectWebElement selectWebElement = new SelectWebElement(GetDateDay());
            selectWebElement.SelectByValue(value);
        }

        // Registration page Date of Birth field Year dropdown
        private IWebElement GetDateYear()
        {
            var element = GetElement(dateYear);
            return element;
        }

        public void SetDateYear(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, dateYear, 1);
            SelectWebElement selectWebElement = new SelectWebElement(GetDateYear());
            selectWebElement.SelectByValue(value);
        }

        // Registration page Username field
        private IWebElement GetUsername()
        {
            var element = GetElement(username);
            return element;
        }

        public void SetUsername(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, username, 1);
            InputElements inputElement = new InputElements(GetUsername());
            inputElement.SendKeys(value);
        }

        // Registration page E-mail field
        private IWebElement GetEmail()
        {
            var element = GetElement(email);
            return element;
        }

        public void SetEmail(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, email, 1);
            InputElements inputElement = new InputElements(GetEmail());
            inputElement.SendKeys(value);
        }

        // Registration page About Yourself field
        private IWebElement GetAboutYourself()
        {
            var element = GetElement(aboutYourself);
            return element;
        }

        public void SetAboutYourself(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, aboutYourself, 1);
            InputElements inputElement = new InputElements(GetAboutYourself());
            inputElement.SendKeys(value);
        }

        // Registration page Password field
        private IWebElement GetPassword()
        {
            var element = GetElement(password);
            return element;
        }

        public void SetPassword(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, password, 1);
            InputElements inputElement = new InputElements(GetPassword());
            inputElement.SendKeys(value);
            WaitHelper.WaitAdditional(1);
        }

        // Registration page Confirm Password field
        private IWebElement GetConfirmPassword()
        {
            var element = GetElement(confirmPassword);
            return element;
        }

        public void SetConfirmPassword(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, confirmPassword, 1);
            InputElements inputElement = new InputElements(GetConfirmPassword());
            inputElement.SendKeys(value);
        }

        // Registration page workflow
        private void FillRegistrationPage(RegistrationPage registrationPage)
        {
            SetFirstName(registrationPage.FirstName);
            SetLastName(registrationPage.LastName);
            SetHobbyDance();
            SetCountry(registrationPage.Country);
            SetPhoneNumber(registrationPage.PhoneNumber);
            SetDateMonth(registrationPage.DateMonth);
            SetDateDay(registrationPage.DateDay);
            SetDateYear(registrationPage.DateYear);
            SetUsername(registrationPage.Username);
            SetEmail(registrationPage.Email);
            SetAboutYourself(registrationPage.AboutYourself);
            SetPassword(registrationPage.Password);
            SetConfirmPassword(registrationPage.ConfirmPassword);
        }

        private static RegistrationPage AddRegistrationPage()
        {
            var registrationPage = new RegistrationPage
            {
                FirstName = RandomDataGenerator.RandomName(8),
                LastName = RandomDataGenerator.RandomName(5) + "-" + RandomDataGenerator.RandomName(7),
                Country = RandomDataGenerator.RandomStringFromList(countryList),
                DateMonth = RandomDataGenerator.RandomIntegerWithinRange(1, 13).ToString(),
                DateDay = RandomDataGenerator.RandomIntegerWithinRange(1, 32).ToString(),
                DateYear = RandomDataGenerator.RandomIntegerWithinRange(1950, 2015).ToString(),
                PhoneNumber = "0" + RandomDataGenerator.RandomDigitString(9),
                Username = RandomDataGenerator.RandomString(10),
                Email = RandomDataGenerator.RandomEmailAddress(5),
                AboutYourself = RandomDataGenerator.RandomStringFromList(testList) + RandomDataGenerator.RandomWebAddress(5) +
                    Environment.NewLine + RandomDataGenerator.RandomLetterString(1) + " = " + RandomDataGenerator.RandomPositiveInteger(3) + "; " +
                    RandomDataGenerator.RandomStringFromInput("aAbBcC", 1) + " = " + RandomDataGenerator.RandomNegativeInteger(4) +
                    Environment.NewLine + "Date last century: " + RandomDataGenerator.RandomDateTimeLastCentury() + "; Date today: " +
                    RandomDataGenerator.RandomDateTimeToday(),
                Password = RandomDataGenerator.RandomString(8)
            };
            registrationPage.ConfirmPassword = registrationPage.Password;
            return registrationPage;
        }

        public void AddRegistrationPageWorkflow()
        {
            var registrationPage = AddRegistrationPage();
            FillRegistrationPage(registrationPage);
        }
    }
}