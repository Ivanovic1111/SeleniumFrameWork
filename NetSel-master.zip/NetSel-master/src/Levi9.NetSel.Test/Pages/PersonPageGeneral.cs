﻿using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System;

namespace Levi9.NetSel.Test.Pages
{
    public class PersonPageGeneral:BasePage
    {
        public PersonPageGeneral(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }

        private String getLastName()
        {
            return Driver.FindElement(By.Id("LastName")).Text;
        }


    }
}
