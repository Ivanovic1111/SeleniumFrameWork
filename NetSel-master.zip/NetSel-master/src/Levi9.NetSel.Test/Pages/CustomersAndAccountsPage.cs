﻿using OpenQA.Selenium;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Test.Pages
{
    public class CustomersAndAccountsPage:BasePage
    {
        public CustomersAndAccountsPage(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }

        private IWebElement getCreatePerson()
        {
            return Driver.FindElement(By.XPath("//a[@title='Create Person']"));
        }

        public void clickCreatePerson()
        {
            WaitHelper.WaitUntilElementsArePresent(Driver, By.XPath("//a[@title='Create Person']"),120);
            getCreatePerson().Click();
        }

        private IWebElement getCreateCorporation()
        {
            return Driver.FindElement(By.XPath("//a[@title='Create Corporation']"));
        }

        public void clickCreateCorporation()
        {
            WaitHelper.WaitUntilElementIsClickable(Driver, By.XPath("//a[@title='Create Corporation']"), 4);
            getCreateCorporation().Click();
            WaitHelper.WaitUntilElementIsNotVisible(Driver, By.XPath("//div[contains(@class,'spinner')]"), 8);
        }


    }
}
