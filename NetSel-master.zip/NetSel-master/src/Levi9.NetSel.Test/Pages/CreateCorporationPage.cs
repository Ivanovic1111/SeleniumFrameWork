﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Test.Pages
{
    public class CreateCorporationPage : BasePage
    {
        private static By Dropdown = By.XPath("//div[@class='k-animation-container km-popup']");
        private IWebElement _companyName;

        public CreateCorporationPage(IWebDriver webDriver) : base(webDriver){ }

        public IWebElement CompanyName
        {
            get
            {
                if (_companyName == null)
                {
                    _companyName = Driver.FindElement(By.Id("FullName"));
                }
                return _companyName;
            }
            set
            {
                WaitHelper.WaitUntilElementIsClickable(Driver, By.XPath("//span[@aria-owns='RoleId_listbox']"), 4);
                _companyName.Clear();
                _companyName.SendKeys(value.Text);
                WaitHelper.WaitUntilTextIsPresentInElementValue(Driver, By.Id("FullName"), value.Text, 10);
            }
        }

        public void SetCompanyName(String companyName)
        {
            WaitHelper.WaitUntilElementIsClickable(Driver, By.XPath("//span[@aria-owns='RoleId_listbox']"),4);
            CompanyName.Clear();
            CompanyName.SendKeys(companyName);
            WaitHelper.WaitUntilTextIsPresentInElementValue(Driver, By.Id("FullName"), companyName, 10);
        }

        public void SetStatus(String fieldName, String status_value)
        {
            SetDropdownMethod(GetDropdownID(fieldName), status_value);
        }

        public IWebElement get_save_button()
        {
            return Driver.FindElement(By.Id("submitCorporationForm"));
        }

        public void Save()
        {
            get_save_button().Click();
            WaitHelper.WaitUntilElementIsNotVisible(Driver, By.XPath("//div[contains(@class,'spinner')]"), 8);
        }

        //DropDown Method
        //--------------------------------------------------------------------------------------------------------------------------------//
        public String GetDropdownID(String fieldName)
        {
            return Driver.FindElement(By.XPath("//span[contains(.,'" + fieldName + "')]/following-sibling::div/span[1]")).GetAttribute("aria-owns");
        }

        private IWebElement OpenDropdown(String ElementId)
        {
            return Driver.FindElement(By.XPath("//span[@aria-owns='" + ElementId + "']//span[contains(@class, 'k-icon k-i-arrow-s')]"));
        }


        public void SetDropdownMethod(String ElementId, String category)
        {
            List<IWebElement> list_a;

            //open dropdown 
            WaitHelper.WaitUntilElementIsClickable(Driver, By.XPath("//span[@aria-owns='" + ElementId + "']//span[contains(@class, 'k-icon k-i-arrow-s')]"), 15);
            OpenDropdown(ElementId).Click();
            WaitHelper.WaitUntilElementIsClickable(Driver, By.XPath("//ul[@id='" + ElementId + "']//li[contains(text(),'" + category + "')]"), 15);

            //select value from list and wait until dropdown is closed
            list_a = Driver.FindElement(By.Id(ElementId)).FindElements(By.TagName("li")).ToList();

            foreach (IWebElement we in list_a)
            {
                if (we.Text.Equals(category))
                {
                    we.Click();
                }
            }
            WaitHelper.WaitUntilElementIsNotVisible(Driver, Dropdown, 15);
        }


    }
}
