﻿using Levi9.NetSel.Elements;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace Levi9.NetSel.Test.Pages
{
    public class RandomAccountNumberPage : BasePage
    {
        // id validator page objects
        private readonly By country = By.Name("countrySelectBox");
        private readonly By idNumber = By.Name("idNumber");
        private readonly By validator = By.XPath("//small[@data-fv-result]");
        // iban validator page objects
        private readonly By iban = By.Name("iban");
        // Test data
        private static string CountryNL = "Netherlands";
        private static string Valid = "VALID";
        private static List<string> bankCodeListNL = new List<string> { "ABNA", "ABNC", "BOFA" };

        public RandomAccountNumberPage(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }
        
        public class ValidatorPage
        {
            public string Country { get; set; }
            public string IdNumber { get; set; }
            public string Iban { get; set; }
        }

        // id validator page Country dropdown
        private IWebElement GetCountry()
        {
            var element = GetElement(country);
            return element;
        }

        public void SetCountry(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, country, 1);
            SelectWebElement selectWebElement = new SelectWebElement(GetCountry());
            selectWebElement.SelectByText(value);
        }

        // id validator page ID number field
        private IWebElement GetIdNumber()
        {
            var element = GetElement(idNumber);
            return element;
        }

        public void SetIdNumber(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, idNumber, 1);
            InputElements inputElement = new InputElements(GetIdNumber());
            inputElement.SendKeys(value);
        }

        // id/iban validator page Validator
        public bool GetValidity()
        {
            var isValid = false;
            var validity = GetElement(validator).GetAttribute("data-fv-result");
            if (validity.Equals(Valid)) isValid = true;
            return isValid;
        }

        // iban validator page IBAN field
        private IWebElement GetIban()
        {
            var element = GetElement(iban);
            return element;
        }

        public void SetIban(string value)
        {
            WaitHelper.WaitUntilElementExistsAndIsClickable(Driver, iban, 1);
            InputElements inputElement = new InputElements(GetIban());
            inputElement.SendKeys(value);
        }

        // id validator page workflow
        private void FillIdValidatorPage(ValidatorPage validatorPage)
        {
            SetCountry(validatorPage.Country);
            SetIdNumber(validatorPage.IdNumber);
        }

        private static ValidatorPage AddIdValidatorPage()
        {
            var validatorPage = new ValidatorPage
            {
                Country = CountryNL,
                IdNumber = RandomAccountNumber.GenerateRandomBsnNumberNL()
            };
            return validatorPage;
        }

        public void AddIdValidatorPageWorkflow()
        {
            var validatorPage = AddIdValidatorPage();
            FillIdValidatorPage(validatorPage);
        }

        // iban validator page workflow
        private void FillIbanValidatorPage(ValidatorPage validatorPage)
        {
            SetIban(validatorPage.Iban);
        }

        private static ValidatorPage AddIbanValidatorPage()
        {
            var bankCodeNL = RandomDataGenerator.RandomStringFromList(bankCodeListNL);
            var validatorPage = new ValidatorPage
            {
                Iban = RandomAccountNumber.GenerateRandomIbanNL(bankCodeNL)
            };
            return validatorPage;
        }

        public void AddIbanValidatorPageWorkflow()
        {
            var validatorPage = AddIbanValidatorPage();
            FillIbanValidatorPage(validatorPage);
        }
    }
}