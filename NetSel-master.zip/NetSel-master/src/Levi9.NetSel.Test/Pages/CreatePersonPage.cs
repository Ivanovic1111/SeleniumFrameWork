﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Test.Pages
{
    public class CreatePersonPage:BasePage
    {
        public CreatePersonPage(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }

        private IWebElement getLastName()
        {
            return Driver.FindElement(By.Id("LastName"));
        }

        public void setLastName(String lastname)
        {
            getLastName().Clear();
            getLastName().SendKeys(lastname);
        }

        public void setNationality(String nationality)
        {
            getNationalityDropDown().Click();
            By by = By.XPath("//ul[(@id='NationalityId_listbox') and (@aria-hidden='false')]//li[contains(text(),'" + nationality + "')]");
            WaitHelper.WaitUntilElementsArePresent(Driver, by, 60);

            Driver.FindElement(by).Click();
            WaitHelper.WaitAdditional(3);
        }

        private IWebElement getNationalityDropDown()
        {
            By by = By.XPath("(//span[contains(@aria-owns, 'NationalityId_listbox')]//span[contains(@class, 'k-icon k-i-arrow-s')])");
            WaitHelper.WaitUntilElementsArePresent(Driver, by, 60);
            return Driver.FindElement(by);

        }

        public void clickOnSave()
        {
            WaitHelper.WaitUntilElementsArePresent(Driver, By.Id("submitPersonForm"), 60);
            Driver.FindElement(By.Id("submitPersonForm")).Click();
        }

        public Boolean isNationalityErrorMessageDisplayed()
        {
            return Driver.FindElement(By.XPath("//span[@data-valmsg-for='NationalityId']")).Displayed;
        }

        private IWebElement genderDropdown()
        {
            return Driver.FindElement(By.XPath("//span[contains(@aria-owns, 'GenderKey_listbox')]//span[contains(@class, 'k-icon k-i-arrow-s')]"));
        }

        public List<String> getPersonGenders()
        {

            List<String> listOfGenders = new List<String>();
            genderDropdown().Click();
            WaitHelper.WaitAdditional(5);
            IList<IWebElement> listOfLiTags = new List<IWebElement>();
            listOfLiTags = Driver.FindElement(By.Id("GenderKey_listbox")).FindElements(By.TagName("li"));
            foreach (IWebElement we in listOfLiTags)
            {
                String text = we.Text;
                if (!text.Equals(""))
                {
                    listOfGenders.Add(we.Text);
                }
            }
            return listOfGenders;

        }

    }
}
