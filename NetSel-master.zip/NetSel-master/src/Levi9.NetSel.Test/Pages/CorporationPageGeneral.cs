﻿using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System;

namespace Levi9.NetSel.Test.Pages
{
    class CorporationPageGeneral:BasePage
    {

        public CorporationPageGeneral(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }

        public String getCorporationName()
        {
            return Driver.FindElement(By.XPath("//div[@data-pending-change-id='companyName']//p[@class='texbox-formatter']")).Text;
        }

        public String getCorporationStatus()
        {
            return Driver.FindElement(By.XPath("//div[@data-pending-change-id='status']")).Text;
        }
    }
}
