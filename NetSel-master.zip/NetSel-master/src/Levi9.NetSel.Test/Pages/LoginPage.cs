﻿using Levi9.NetSel.Elements;
using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System;

namespace Levi9.NetSel.Test.Pages
{
    public class LoginPage : BasePage
    {

        public LoginPage(IWebDriver webDriver) : base(webDriver)
        {

            webDriver = Driver;

        }

        public IWebElement getUsername()
        {
            return Driver.FindElement(By.Id("Username"));
        }

        public void setUsername(String username)
        {
            getUsername().SendKeys(username);
        }

        public IWebElement getPassword()
        {
            return Driver.FindElement(By.Id("Password"));
        }

        public void setPassword(String password)
        {
            getPassword().SendKeys(password);
        }

        public ClickableElements GetSignIn()
        {
            return new ClickableElements(Driver.FindElement(By.XPath("//input[@title= 'Sign In']")));
        }

        public void ClickSignIn()
        {
            GetSignIn().Click();

        }

        public void Login(String username, String password)
        {
            setUsername(username);
            setPassword(password);
            ClickSignIn();
        }

    }
}
