﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Test.Pages
{
    public class DropdownClass:BasePage
    {
        public static By dropdown = By.XPath("//div[@class='k-animation-container km-popup']");

        public DropdownClass(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
       
        }

        //DropDown Method
        //--------------------------------------------------------------------------------------------------------------------------------//
        public String getIDofDropdown(String fieldName)
        {
            return Driver.FindElement(By.XPath("//span[contains(.,'" + fieldName + "')]/following-sibling::div/span[1]")).GetAttribute("aria-owns");
        }

        private IWebElement openDropdown(String ElementId)
        {
            return Driver.FindElement(By.XPath("//span[@aria-owns='" + ElementId + "']//span[contains(@class, 'k-icon k-i-arrow-s')]"));
        }


        public void setDropdownMethod(String ElementId, String category)
        {
            List<IWebElement> list_a = new List<IWebElement>();

            //open dropdown 
            WaitHelper.WaitUntilElementIsClickable(Driver, By.XPath("//span[@aria-owns='" + ElementId + "']//span[contains(@class, 'k-icon k-i-arrow-s')]"), 15);
            openDropdown(ElementId).Click();
            WaitHelper.WaitUntilElementIsClickable(Driver, By.XPath("//ul[@id='" + ElementId + "']//li[contains(text(),'" + category + "')]"), 15);

            //select value from list and wait until dropdown is closed
            list_a = Driver.FindElement(By.Id(ElementId)).FindElements(By.TagName("li")).ToList();

            foreach (IWebElement we in list_a)
            {
                if (we.Text.Equals(category))
                {
                    we.Click();
                }
            }
            WaitHelper.WaitUntilElementIsNotVisible(Driver, dropdown, 15);
        }
    }
}
