﻿using OpenQA.Selenium;
using System;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Test.Pages
{
    public class HomePage:BasePage
    {

        public By infoEmailInTreeView = By.XPath("//a[contains(@href, 'info@fivedegrees.is')]");
        
        public HomePage(IWebDriver webDriver) : base(webDriver)
        {
            webDriver = Driver;
        }

        public IWebElement getCustomersAndAccounts()
        {
            return Driver.FindElement(By.XPath("//a[@title='Customers & Accounts']"));
        }

        public void clickCustomerAndAccounts()
        {
            WaitHelper.WaitUntilElementsArePresent(Driver, By.XPath("//a[@title='Customers & Accounts']"), 30);
            getCustomersAndAccounts().Click();
            WaitHelper.WaitUntilElementsArePresent(Driver, By.XPath("//a[@title='Create Person']"), 30);
        }

        public String returnLogedInUsername()
        {
            return Driver.FindElement(By.XPath("//div[contains(@class, 'user-information')]")).Text;
        }



    }
}
