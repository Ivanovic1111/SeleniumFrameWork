﻿using System.Collections.Generic;
using Xunit;
using System.Configuration;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;
using Levi9.NetSel.IO;
using Levi9.NetSel.DB;

namespace Levi9.NetSel.Test.Tests
{
    public class CheckPersonGenderDropDownValues : BaseTest
    {


        [Fact]
        public void checkPersonGenderDropDownValuesTest()
        {
            var url = ConfigurationManager.AppSettings["fdtest1"];
            var username = ConfigurationManager.AppSettings["username"];
            var password = ConfigurationManager.AppSettings["password"];

            OpenPage(url);
            MaximizeBrowser();

            LoginPage loginPage = new LoginPage(Driver);
            HomePage homePage = new HomePage(Driver);
            CustomersAndAccountsPage customersAndAccounts = new CustomersAndAccountsPage(Driver);
            CreatePersonPage createPersonPage = new CreatePersonPage(Driver);
            //SQLTestDataHelper td = new SQLTestDataHelper();
            DatabaseHelper th = new DatabaseHelper("testDB");

            loginPage.Login(username, password);
            WaitHelper.WaitUntilElementsArePresent(Driver, homePage.infoEmailInTreeView, 30);
            homePage.clickCustomerAndAccounts();
            customersAndAccounts.clickCreatePerson();
            WaitHelper.WaitAdditional(3);
            List<string> actuallistOfGenders = createPersonPage.getPersonGenders();
            //List<string> expectedListOfGenders = td.getGendersOnPersonsPage();
            List<string> expectedListOfGenders = th.queryForListOfResults("SELECT Name FROM ReferenceData.Genders");
            actuallistOfGenders.Sort();
            expectedListOfGenders.Sort();
            Assert.Equal(expectedListOfGenders, actuallistOfGenders);
            Driver.Dispose();

        }

    }
}
