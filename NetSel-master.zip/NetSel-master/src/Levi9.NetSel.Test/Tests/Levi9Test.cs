﻿using OpenQA.Selenium;
using Levi9.NetSel.Helpers;
using Xunit;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;
using System.Configuration;

namespace Levi9.NetSel.Test
{
    public class Levi9Test : BaseTest
    {
      private Levi9_HomePage _home;

      public Levi9Test() {

            _home = new Levi9_HomePage(Driver);
        }

        [Fact]
        public void Open_Levi9()
        {
            //navigate to application
            OpenPage(ConfigurationManager.AppSettings["levi9Url"]);
            MaximizeBrowser();

            //wait for logo to be visible
            WaitHelper.WaitUntilElementExists(Driver, _home._logo, 3);

            // verify there is 'One plus one equals nine'
            Assert.Equal("One plus one equals nine", _home.GetAboutUs());

            //release web driver
            Driver.Dispose();
            
        }

    }

    }
