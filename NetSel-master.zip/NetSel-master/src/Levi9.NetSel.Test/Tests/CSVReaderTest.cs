﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Levi9.NetSel.Helpers;
using Xunit;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;
using System.Configuration;

using Levi9.NetSel.IO;
using Levi9.NetSel.DB;


namespace Levi9.NetSel.Test.Tests
{
    public class CSVReaderTest
    {
        public string path = "../../resources/Documents/csv_temp.csv";
        public string delimiter = ",";



        [Fact]
        public void TestCSVReader() {

            var result = new List<string[]>();
            var resultexp = new List<string[]>();

            result = CSVReader.parseCSV(path, delimiter);

            var test1 = new string[3];
            test1[0] = "ds";
            test1[1] = "ko";
            test1[2] = "ddd";
           
            resultexp.Add(test1);

            var test2 = new string[3];
            test2[0] = "ds";
            test2[1] = "dm";
            test2[2] = "ls";
            resultexp.Add(test2);


            var test3 = new string[3];
            test3[0] = "lkj";
            test3[1] = "dssl";
            test3[2] = "14/01/2015";
            resultexp.Add(test3);
     


            Assert.Equal(resultexp, result);

        }
    }
}
