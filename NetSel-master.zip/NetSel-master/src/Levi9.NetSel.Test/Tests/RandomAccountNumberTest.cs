﻿using OpenQA.Selenium;
using Xunit;
using Levi9.NetSel.Test.Pages;
using OpenQA.Selenium.Chrome;
using System;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;

namespace Levi9.NetSel.Test.Tests
{
    public class RandomAccountNumberTest: IDisposable
    {
        IWebDriver driver = new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());
        private static string baseUrl = "http://formvalidation.io/";

        [Fact]
        public void PopulateIdValidatorPageUsingValidBsnNumber()
        {
            var validatorPage = new RandomAccountNumberPage(driver);

            // Start browser
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(baseUrl + "validators/id/basic/bootstrap.html");

            // Populate id validator page
            validatorPage.AddIdValidatorPageWorkflow();

            // Assert if ID number is valid
            Assert.True(validatorPage.GetValidity(), "Entered ID number is not valid for selected country!");
        }

        [Fact]
        public void PopulateIdValidatorPageUsingInvalidBsnNumber()
        {
            var validatorPage = new RandomAccountNumberPage(driver);

            // Start browser
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(baseUrl + "validators/id/basic/bootstrap.html");

            // Populate id validator page
            validatorPage.SetCountry("Netherlands");
            validatorPage.SetIdNumber("123456789");

            // Assert if ID number is not valid
            Assert.False(validatorPage.GetValidity(), "Entered ID number is valid for selected country!");
        }

        [Fact]
        public void PopulateIbanValidatorPageUsingValidIban()
        {
            var validatorPage = new RandomAccountNumberPage(driver);

            // Start browser
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(baseUrl + "validators/iban/basic/bootstrap.html");

            // Populate iban validator page
            validatorPage.AddIbanValidatorPageWorkflow();

            // Assert if IBAN is valid
            Assert.True(validatorPage.GetValidity(), "Entered IBAN is not valid!");
        }

        [Fact]
        public void PopulateIbanValidatorPageUsingInvalidIban()
        {
            var validatorPage = new RandomAccountNumberPage(driver);

            // Start browser
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(baseUrl + "validators/iban/basic/bootstrap.html");

            // Populate iban validator page
            validatorPage.SetIban("NL00ABCD1234567890");

            // Assert if IBAN is not valid
            Assert.False(validatorPage.GetValidity(), "Entered IBAN is valid!");
        }

        public void Dispose()
        {
            driver.Dispose();
        }
    }
}