﻿using Levi9.NetSel.Elements;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Xml;
using Xunit;

namespace Levi9.NetSel.Test.Tests
{
    public class InputElementsTests: IDisposable

    {

        IWebDriver driver =  new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());
      

        public IWebElement GetInput()
        {
            By by = By.XPath("//input[@name=\"firstname\"]");
            return driver.FindElement(by);
        }

        [Fact]
        public void SendKeysTest()
        {
            string inputValue = "test";
            By by = By.XPath("//input[@name=\"firstname\"]");
            driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_forms.asp");
            InputElements input = new InputElements(GetInput());

            input.SendKeys(inputValue);
            Assert.Equal(input.GetAttribute("value"), inputValue);
            
        }

        [Fact]
        public void ClearKeysTest()
        {
            By by = By.XPath("//input[@name=\"firstname\"]");
            string inputValue = "";

            driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_forms.asp");
            InputElements input = new InputElements(GetInput());

            input.SendKeys(inputValue);
            input.ClearField();
            Assert.Equal(input.GetAttribute("value"), inputValue);
         
        }

        [Fact]
        public void FillHiddenTest()
        {

            By by = By.Id("gs_taif0");
            string inputValue = "test";

            driver.Navigate().GoToUrl("https://www.google.rs/#gws_rd=cr,ssl");
            InputElements input = new InputElements(driver.FindElement(by));

            input.FillHiddenField(driver, inputValue);

        }

        public void Dispose()
        {
            driver.Dispose();
        }
    }
}
