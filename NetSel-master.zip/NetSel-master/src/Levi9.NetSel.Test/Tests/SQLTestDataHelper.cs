﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using Levi9.NetSel.DB;


namespace Levi9.NetSel.Test.Tests
{
    public class SQLTestDataHelper
    {
        DatabaseHelper dh = new DatabaseHelper("testDB");
        private static readonly string CONNECTION_STRING = ConfigurationManager.ConnectionStrings["testDB"].ConnectionString;
        public string getFullName()
        {
            
            string result = null;
            
            using (SqlConnection conn = dh.createConnection())
            {
                using (SqlCommand comm = dh.createSelectCommand(conn, "DisplayName", "CRM.PersonAccess", new SqlParameter("@Username", ConfigurationManager.AppSettings["username"])))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    result = dr.GetString(0);
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }

            return result;

        }

        public int getCenterId()
        {
            int result = 0;


            using (SqlConnection conn = dh.createConnection())
            {
                using (SqlCommand comm = dh.createSelectCommand(conn, "CenterId", "CRM.PersonAccess", new SqlParameter("@Username", ConfigurationManager.AppSettings["username"]), new SqlParameter("@CenterId", 1)))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    result = dr.GetInt32(0);
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }

            return result;

        }


        public List<string> getGendersOnPersonsPage()
        {
            List<string> resultList = new List<string>();
            using (SqlConnection conn = dh.createConnection())
            {
                using (SqlCommand comm = dh.createSelectCommand(conn, "Name", "ReferenceData.Genders", null))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                { 
                                    resultList.Add(dr.GetString(0));
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }
            return resultList;
        }
    }
}
