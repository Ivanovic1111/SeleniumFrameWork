﻿using Levi9.NetSel.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using System.Xml;
using System.Xml.Linq;

namespace Levi9.NetSel.Test.Tests
{
    public class XML_Test : BaseTest
    {
        string pathToXML = "../../resources/Documents/TestsData.xml";

        [Fact]
        public void XMLTest1()
        {

            string key_value = XmlHelper.GetValueByKey("lastname", pathToXML);
            Assert.Equal("testLastName", key_value);

            Exception ex = Assert.Throws<Exception>(() => XmlHelper.GetValueByKey("DD", pathToXML));
            Assert.Equal("Key DD does not exist in current XML document", ex.Message);
        }

        [Fact]
        public void XMLTest2()
        {
            String pathToXMLFile = "../../resources/Documents/XMLFile1.xml";

            //XmlReader xml = new XmlReader();

            List<string> xmlElements = XmlHelper.ListOfXMLTagValues("FirstName", pathToXMLFile);

            Assert.Equal("Pera", xmlElements[0]);
            Assert.Equal("Marko", xmlElements[1]);
            Assert.True(xmlElements.Contains("Marko"));
        }

        [Fact]
        public void SelectSingleNodeTest()
        {
            String pathToXMLFile = "../../resources/Documents/XMLFile1.xml";
            
            string xmlElement = XmlHelper.SelectSingleNode("//Persons/Person[@id='10']", pathToXMLFile);
            Assert.Equal(xmlElement, "Pera Persic");
        }

        [Fact]
        public void ReplaceNode()
        {
            String pathToXMLFile = "../../resources/Documents/XMLFile1.xml";

            string xmlTest =
            @"<FirstName>Perha </FirstName>
    <LastName>Persichh</LastName>";
            XmlHelper.ReplaceChild("//Person[2]", "Person", xmlTest, pathToXMLFile);

            List<string> xmlElements = XmlHelper.ListOfXMLTagValues("FirstName", pathToXMLFile);
            Assert.Contains(xmlElements[1], "Perha");


            xmlTest =
                @"<FirstName>Marko</FirstName>
    <LastName>Markovic</LastName>
  ";
            XmlHelper.ReplaceChild("//Person[2]", "Person", xmlTest, pathToXMLFile);
            xmlElements = XmlHelper.ListOfXMLTagValues("FirstName", pathToXMLFile);
            Assert.Contains(xmlElements[1], "Marko");

        }

        [Fact]
        public void XML_Write_Overwrite_value()
        {

            XmlHelper.WriteIntoXML(pathToXML, "D", "SukaABC");
            Assert.Equal("SukaABC", XmlHelper.GetValueByKey("D", pathToXML));

            Exception ex = Assert.Throws<Exception>(() => XmlHelper.WriteIntoXML(pathToXML, "D", "SukaABC"));
            Assert.Equal("Key D alrady exist in XML document!", ex.Message);


            //remove added xml node
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(pathToXML);
            XDocument doca = XDocument.Load(pathToXML);
           
            XElement elm = doca.Root.Elements().FirstOrDefault(e => e.Attribute("key").Value == "D");
            if (elm!=null)
            {
                xDoc.GetElementsByTagName("testData")[0].RemoveChild(
                xDoc.GetElementsByTagName("testData")[0].LastChild);
            }
            xDoc.Save(pathToXML);
        }
    }

}
