﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Levi9.NetSel.Elements;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using Xunit;
using System.Configuration;
using Levi9.NetSel.Test.Pages;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;

namespace Levi9.NetSel.Test
{
    public class TextElementTest :IDisposable
    {

        private By byWelcome = By.XPath(".//*[@id='LoginForm']/div[1]/p[2]");
        private By bySubmit = By.XPath("//input[@type=\"submit\"]");
        IWebDriver driver = new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());

        [Fact]
        public void getTextTest()
        {
            driver.Navigate().GoToUrl("http://fdtest1.fivedegrees.local/");
            TextElements input = new TextElements(driver.FindElement(bySubmit));

            string result = input.getValue();

            Assert.Equal("Sign In", result);
            driver.Dispose();

        }

        [Fact]
        public void getTexttestWelcome() {
            driver.Navigate().GoToUrl("http://fdtest1.fivedegrees.local/");
            TextElements input = new TextElements(driver.FindElement(byWelcome));

            string result = input.getText();

            Assert.Equal("Welcome, please sign in using your credentials", result);
            driver.Dispose();


        }


       
        public void Dispose()
        {
            driver.Dispose();
        }

    }
}
