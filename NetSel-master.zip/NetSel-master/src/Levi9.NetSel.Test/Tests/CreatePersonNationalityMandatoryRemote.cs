﻿using System;
using Levi9.NetSel.Helpers;
using Xunit;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;

namespace Levi9.NetSel.Test.Tests
{
    public class CreatePersonNationalityMandatoryRemote : BaseTest
    {

        //[Fact]
        public void checkPersonNationalityMandatoryRemote()
        {

            //useRemote = true;
            LoginPage loginPage = new LoginPage(Driver);
            HomePage homePage = new HomePage(Driver);
            CustomersAndAccountsPage customersAndAccounts = new CustomersAndAccountsPage(Driver);
            CreatePersonPage createPersonPage = new CreatePersonPage(Driver);

            OpenPage("http://fdtest1.fivedegrees.local");
            MaximizeBrowser();

            loginPage.Login("m.maletic", "Levi9Pass1");
            WaitHelper.WaitUntilElementsArePresent(Driver, homePage.infoEmailInTreeView, 30);
            homePage.clickCustomerAndAccounts();
            customersAndAccounts.clickCreatePerson();

            createPersonPage.setLastName("milica");
            createPersonPage.clickOnSave();
            Console.Write(createPersonPage.isNationalityErrorMessageDisplayed());
            Assert.Equal(true, createPersonPage.isNationalityErrorMessageDisplayed());
            Driver.Dispose();

        }

    }
}
