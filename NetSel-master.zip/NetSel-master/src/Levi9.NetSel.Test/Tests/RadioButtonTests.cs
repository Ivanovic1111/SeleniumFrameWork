﻿using Levi9.NetSel.Elements;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System;
using Xunit;

namespace Levi9.NetSel.Test.Tests
{
    public class RadioButtonTests : IDisposable
    {
        IWebDriver driver = new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());

        public IWebElement GetInput()
        {
            By by = By.XPath("//input[(@name='gender')][3]");
            return driver.FindElement(by);
        }

        [Fact]
        public void SelectButtonObjectTest()
        {
            driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_forms.asp");
            RadioButton rbElement = new RadioButton(GetInput());

            rbElement.SelectValue();
           
            Assert.True(rbElement.IsSelected());
            
        }


        public void Dispose()
        {
            driver.Dispose();
        }

    }
}
