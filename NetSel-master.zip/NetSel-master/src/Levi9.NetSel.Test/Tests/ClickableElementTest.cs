﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Levi9.NetSel.Elements;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using Xunit;
using Levi9.NetSel.Test;
using OpenQA.Selenium.Remote;

namespace Levi9.NetSel.Test
{
    public class ClickableElementTest : IDisposable
    {
      
            IWebDriver driver = new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());


        public IWebElement GetButton()
            {
                By by = By.XPath("//button[@type='button']");
                return driver.FindElement(by);
            }

            [Fact]
            public void CheckDisplayed()
            {
                driver.Navigate().GoToUrl("http://www.w3schools.com/tags/tag_button.asp");
                ClickableElements input = new ClickableElements(GetButton());

                bool isDisplayed = input.IsDisplayed();

                Assert.False(isDisplayed);
                driver.Dispose();

            }

        [Fact]
        public void CheckEnabled()
        {
            driver.Navigate().GoToUrl("http://www.w3schools.com/tags/tag_button.asp");
            ClickableElements input = new ClickableElements(GetButton());

            bool isEnabled = input.IsEnabled();

            Assert.True(isEnabled);
            driver.Dispose();

        }


        public void Dispose()
        {
            driver.Dispose();
        }

    }
}
