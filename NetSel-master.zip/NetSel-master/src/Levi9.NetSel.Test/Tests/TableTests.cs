﻿using Levi9.NetSel.Elements;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System;
using Xunit;

namespace Levi9.NetSel.Test.Tests
{
    public class TableTests :IDisposable
    {
        IWebDriver driver = new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());

        public IWebElement GetTable()
        {
            By by = By.Id("customers");
            return driver.FindElement(by);
        }

        [Fact]
        public void GetCellByLocatorTest()
        {
            driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_tables.asp");
            Table table = new Table(driver.FindElement(By.XPath("//table[@id='customers']")));
            By locator = By.XPath("//tr[2]/td[2]");

            Assert.Equal(table.GetCellByLocator(locator), "Maria Anders");
            
        }

        [Fact]
        public void GetElementsByRowTest()
        {
            driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_tables.asp");
            Table table = new Table(GetTable());

            Assert.Equal(table.GetElementsByRow()[3], "Ernst Handel Roland Mendel Austria");
           
        }

        [Fact]
        public void GetHeadersTest()
        {
            driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_tables.asp");
            Table table = new Table(GetTable());

            Assert.Equal(table.GetHeaders()[0], "Company");
            Assert.Equal(table.GetHeaders()[1], "Contact");
            Assert.Equal(table.GetHeaders()[2], "Country");
           
        }

        [Fact]
        public void GetRowsNumberTest()
        {
            driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_tables.asp");
            Table table = new Table(driver.FindElement(By.XPath("//table[@id='customers']")));
        
            Assert.Equal(table.GetRowSize().ToString(), "7");
            Assert.Equal(table.GetColumnSize().ToString(), "3");
            
        }

        public void Dispose()
        {
            driver.Dispose();
        }
    }
}
