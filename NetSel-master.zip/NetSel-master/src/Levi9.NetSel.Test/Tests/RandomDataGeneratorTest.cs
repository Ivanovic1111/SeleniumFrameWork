﻿using OpenQA.Selenium;
using Xunit;
using Levi9.NetSel.Test.Pages;
using System;
using OpenQA.Selenium.Remote;

namespace Levi9.NetSel.Test.Tests
{
    public class RandomDataGeneratorTest: IDisposable
    {
        IWebDriver driver = new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());
        private static string baseUrl = "http://demoqa.com/registration/";

        [Fact]
        public void PopulateRegistrationPageUsingRandomDataGenerator()
        {
            var registrationPage = new RandomDataGeneratorPage(driver);

            // Start browser
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(baseUrl);

            // Populate Registration page
            registrationPage.AddRegistrationPageWorkflow();
        }

        public void Dispose()
        {
            driver.Dispose();
        }
    }
}