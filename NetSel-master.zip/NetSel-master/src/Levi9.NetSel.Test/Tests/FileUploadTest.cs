﻿using Levi9.NetSel.Elements;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System;
using Xunit;

namespace Levi9.NetSel.Test.Tests
{

    public class FileUploadTest : IDisposable
    {
        IWebDriver driver = new RemoteWebDriver(new Uri("http://selenium.cloud.levi9.com:4444/wd/hub"), DesiredCapabilities.Firefox());

        public void Dispose()
        {
            driver.Dispose();
        }

        [Fact]
        public void fileUpload()
        {
            driver.Navigate().GoToUrl("http://cgi-lib.berkeley.edu/ex/fup.html");
            string elXpath = "//input[@type=\"file\"]";
            string filePath = "..\\..\\TestsData.xml";
            IWebElement element = driver.FindElement(By.XPath("//input[@type=\"file\"]"));
          
            FileUpload fileUp = new FileUpload(driver);
            fileUp.selectFile(elXpath,filePath);
            Dispose();
        }
    }
}
