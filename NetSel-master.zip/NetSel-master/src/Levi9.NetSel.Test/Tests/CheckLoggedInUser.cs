﻿using System;
using System.Configuration;
using Levi9.NetSel.Helpers;
using Xunit;
using OpenQA.Selenium;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;
using Xunit.Abstractions;
using Levi9.NetSel.IO;
using Levi9.NetSel.DB;

namespace Levi9.NetSel.Test.Tests
{

    public class CheckLoggedInUser : BaseTest
        
    {
       // ITestOutputHelper output;


        [Fact]
        public void Test()
        {
            var url = ConfigurationManager.AppSettings["fdtest1"];
            var username = ConfigurationManager.AppSettings["username"];
            var password = ConfigurationManager.AppSettings["password"];



            OpenPage(url);
            MaximizeBrowser();

            LoginPage loginPage = new LoginPage(Driver);
            HomePage homePage = new HomePage(Driver);
            DatabaseHelper dh = new DatabaseHelper("testDB");

            //Log in 
            Console.WriteLine("User will now login");
            SQLTestDataHelper dt = new SQLTestDataHelper();
            loginPage.Login(ConfigurationManager.AppSettings["username"], ConfigurationManager.AppSettings["password"]);
            WaitHelper.WaitUntilElementsArePresent(Driver, By.XPath("//a[contains(@href, 'info@fivedegrees.is')]"), 30);
            string fullname = homePage.returnLogedInUsername();
            // string expectedFullName = dh.queryForSingleResultAsString("SELECT displayName FROM crm.PersonAccess WHERE username = '" + ConfigurationManager.AppSettings["username"] + "'");
            string expectedFullName = "Maja M Maletic";
            Assert.Equal(expectedFullName, fullname);
            Driver.Dispose();

            //output.WriteLine("This is output from CheckLogedInUser");

        }


    }
}
