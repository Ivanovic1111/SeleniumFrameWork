﻿using Xunit;
using OpenQA.Selenium;
using Levi9.NetSel.Helpers;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;

namespace Levi9.NetSel.Test.Tests
{
    public class CreatePersonTest : BaseTest 
    {

        [Fact]
        public void checkCreatePerson()
        {
            OpenPage("http://fdtest1.fivedegrees.local");
            MaximizeBrowser();

            LoginPage loginPage = new LoginPage(Driver);
            HomePage homePage = new HomePage(Driver);
            CustomersAndAccountsPage customersAndAccounts = new CustomersAndAccountsPage(Driver);
            CreatePersonPage createPersonPage = new CreatePersonPage(Driver);

            loginPage.Login("m.maletic", "Levi9Pass1");
            WaitHelper.WaitUntilElementsArePresent(Driver, homePage.infoEmailInTreeView, 30);
            homePage.clickCustomerAndAccounts();
            customersAndAccounts.clickCreatePerson();

            createPersonPage.setLastName("milica");
            createPersonPage.setNationality("Dubai");

            createPersonPage.clickOnSave();
            WaitHelper.WaitUntilElementsArePresent(Driver, By.Id("editPerson"), 60);

            Driver.Dispose();

        }

    }
}
