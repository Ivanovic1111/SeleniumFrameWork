﻿using OpenQA.Selenium;
using System;
using Levi9.NetSel.Helpers;
using Xunit;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;

namespace Levi9.NetSel.Test.Tests
{
    public class CreateCorporationTest : BaseTest
    {

        [Fact]
        public void createCorporationTest()
        {

            LoginPage loginPage = new LoginPage(Driver);
            HomePage homePage = new HomePage(Driver);
            CustomersAndAccountsPage customersAndAccounts = new CustomersAndAccountsPage(Driver);
            CreateCorporationPage createCorporationPage = new CreateCorporationPage(Driver);
            CorporationPageGeneral corporationPageGeneral = new CorporationPageGeneral(Driver);

            String Corporation_Name = "Company" + Guid.NewGuid();
            String Corporation_Status = "Closed";


            //start browser
            OpenPage("http://fdtest1.fivedegrees.local");
            MaximizeBrowser();

            //log in
            loginPage.Login("m.maletic", "Levi9Pass1");
            WaitHelper.WaitUntilElementsArePresent(Driver, By.XPath("//a[contains(@href, 'info@fivedegrees.is')]"), 30);
            homePage.clickCustomerAndAccounts();
            customersAndAccounts.clickCreateCorporation();

            //create Corporation
            createCorporationPage.SetCompanyName(Corporation_Name);
            //createCorporationPage.CompanyName.Text = Corporation_Name;
            createCorporationPage.SetStatus("Status", Corporation_Status);
            createCorporationPage.Save();
            // WaitHelper.waitAdditional(4);

            //verify name and status 
            Assert.Equal(Corporation_Name, corporationPageGeneral.getCorporationName());
            Assert.Equal(Corporation_Status, corporationPageGeneral.getCorporationStatus());

            //drop browser
            Driver.Dispose();
        }

    }
}
