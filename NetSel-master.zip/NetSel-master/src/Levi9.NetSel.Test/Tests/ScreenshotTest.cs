﻿using OpenQA.Selenium;
using System;
using System.Configuration;
using System.IO;
using Levi9.NetSel.Helpers;
using Xunit;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Test.Tests
{
    public class ScreenshotTest : BaseTest
    {
   

        [Fact]
        public void Test()
        {
            String root = "../../resources/screenshot/";
            String picture_name = "screenshot.png";

            // delete previous saved screenshot
            File.Delete(root + picture_name);
           Assert.False(File.Exists(picture_name));

            //initialize pages 
            LoginPage loginPage = new LoginPage(Driver);
            HomePage homePage = new HomePage(Driver);
            OpenPage(ConfigurationManager.AppSettings["fdtest1"]);
            MaximizeBrowser();

            //login to url
            loginPage.Login(ConfigurationManager.AppSettings["username"], ConfigurationManager.AppSettings["password"]);
            WaitHelper.WaitUntilElementsArePresent(Driver, By.XPath("//a[contains(@href, 'info@fivedegrees.is')]"), 30);

            //navigate to Customer and Account page 
            homePage.clickCustomerAndAccounts();

            ScreenShotHelper.captureScreenshot(Driver, picture_name);

            //verify that file is saved under location 
            Assert.True( File.Exists(root + picture_name));

            // dispose driver 
            Driver.Dispose();

        }
    }
}
