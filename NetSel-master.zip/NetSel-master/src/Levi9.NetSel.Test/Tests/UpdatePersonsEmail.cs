﻿using System;
using System.Configuration;
using Levi9.NetSel.Helpers;
using Xunit;
using OpenQA.Selenium;
using Levi9.NetSel.Test;
using Levi9.NetSel.Test.Pages;
using Levi9.NetSel.IO;
using Levi9.NetSel.DB;


namespace Levi9.NetSel.Test.Tests
{

    public class UpdatePersonsEmail : BaseTest
        
    {
      //  ITestOutputHelper output;

        [Fact]
        public void Test()
        {
            var url = ConfigurationManager.AppSettings["fdtest1"];
            var username = ConfigurationManager.AppSettings["username"];
            var password = ConfigurationManager.AppSettings["password"];



            OpenPage(url);
            MaximizeBrowser();

            LoginPage loginPage = new LoginPage(Driver);
            HomePage homePage = new HomePage(Driver);
            DatabaseHelper dh = new DatabaseHelper("testDB");

            //Log in 
            Console.WriteLine("User will now login");
            SQLTestDataHelper dt = new SQLTestDataHelper();
            loginPage.Login(ConfigurationManager.AppSettings["username"], ConfigurationManager.AppSettings["password"]);
            WaitHelper.WaitUntilElementsArePresent(Driver, By.XPath("//a[contains(@href, 'info@fivedegrees.is')]"), 30);

            //check execute query and execute query form file
            /*
            string expectedFullName = dh.queryForSingleResultAsString("SELECT displayName FROM crm.PersonAccess WHERE username = '" + ConfigurationManager.AppSettings["username"] + "'");
            dh.executeQuery("UPDATE crm.Persons SET EMail1Address = 'address@newaddress.com' WHERE id = 3267;UPDATE crm.Persons SET EMail1Address = 'address@newaddress.com' WHERE id = 3266");
            string path = @"D:\.NET projects\NetSel\src\Levi9.NetSel.Test\resources\Documents\MyTest.txt";
            dh.executeMultipleQueriesFromFile(path);
            Driver.Dispose();
            */

            //check create file
         //   string path1 = @"D:\.NET projects\NetSel\src\Levi9.NetSel.Test\resources\Documents\Testing123.txt";
            FileHandler fh = new FileHandler();
           // fh.CreateFile(path1);

        //    string path2 = @"D:\.NET projects\NetSel\src\Levi9.NetSel.Test\resources\Documents\Testing1.txt";
          //  fh.WriteTextToFile(path2, "Ovo je text koji treba da se doda");

          //  output.WriteLine("This is output from Update personsEmail");


        }


    }
}
