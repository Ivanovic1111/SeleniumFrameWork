﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;


namespace Levi9.NetSel.IO
{
public class CSVReader
{

    public static List<string[]> parseCSV(string file, string delimiter)
    {
        var parsedData = new List<string[]>();
        string[] fields;

        using (var parser = new TextFieldParser(file))
        {
            parser.TextFieldType = FieldType.Delimited;
            parser.SetDelimiters(delimiter);
            parser.TrimWhiteSpace = true;

            while (!parser.EndOfData)
            {
                fields = parser.ReadFields();
                parsedData.Add(fields);
            }
        }

        return parsedData;
    }
}
}

