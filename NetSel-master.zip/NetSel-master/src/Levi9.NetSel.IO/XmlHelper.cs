﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace Levi9.NetSel.IO
{
    public class XmlHelper
    {

        public static string GetValueByKey(string key, string xmlName)
        {
            var error = String.Format("Key {0} does not exist in current XML document",key);

            XDocument doc = XDocument.Load(xmlName);
            XElement elm = doc.Root.Elements().FirstOrDefault(e => e.Attribute("key") != null && e.Attribute("key").Value == key);

           
            Exception ex = new Exception(error);
            if (elm == null)
            { throw ex; }

            return elm.Attribute("value").Value;
        }

        public static List<string> ListOfXMLTagValues(string tagname, string xmlName)
        {

            XmlDocument xml = new XmlDocument();
            xml.Load(xmlName);
            XmlNodeList XmlNode = xml.GetElementsByTagName(tagname);
            List<string> list = new List<string>();

            for (int i = 0; i <= XmlNode.Count - 1; i++)
            {
                list.Add(XmlNode.Item(i).InnerText.Trim());
            }
            return list;
        }

        public static string SelectSingleNode(string key, string xmlName)
        {
            XmlDocument xml = new XmlDocument();
            XmlNode root;
            xml.Load(xmlName);
            root = xml.DocumentElement;

            return root.SelectSingleNode(key).InnerText.Trim();
        }

        public static void ReplaceChild(string existingNode, string nodeElement, string nodeValue, string xmlName)
        {
            XmlDocument xml = new XmlDocument();
            xml.Load(xmlName);
            XmlNode node = xml.DocumentElement;

            XmlElement newElem = xml.CreateElement(nodeElement);
            newElem.InnerXml = nodeValue;
            node.ReplaceChild(newElem, xml.SelectSingleNode(existingNode));
            xml.Save(xmlName);
        }

        public static void WriteIntoXML(string fileName, string key, string value)
        {
            XmlDocument xDoc = new XmlDocument();
            XDocument doc = XDocument.Load(fileName);
            xDoc.Load(fileName);
            XElement elm = doc.Root.Elements().FirstOrDefault(e =>  e.Attribute("key").Value == key);
          

            XmlNode xNode = xDoc.CreateNode(XmlNodeType.Element, "add", "");
            XmlAttribute xKey = xDoc.CreateAttribute("key");
            XmlAttribute xValue = xDoc.CreateAttribute("value");
            xKey.Value = key;
            xValue.Value = value;
            var a = String.Format("Key {0} alrady exist in XML document!", key);

            Exception ex = new Exception(a);

            if (elm == null)
            {
                xNode.Attributes.Append(xKey);
                xNode.Attributes.Append(xValue);
                xDoc.GetElementsByTagName("testData")[0].InsertAfter(xNode,
                xDoc.GetElementsByTagName("testData")[0].LastChild);
                xDoc.Save(fileName);
            }
            else
            {
                throw ex;
            }
        }

    }
}
