﻿using OpenQA.Selenium;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Elements
{
    public class CheckBox
    {
        readonly IWebElement webElement;

        public CheckBox(IWebElement webElement)
        {
            this.webElement = webElement;

        }

        public void SelectValue()
        {
            webElement.Click();
        }

        public void Unselect()
        {
            if (webElement.Selected)
            {
                webElement.Click();
            }
        }

        public void Select()
        {
            if (!webElement.Selected)
            {
                webElement.Click();
            }
        }

        public string GetValue()
        {
            return webElement.GetAttribute("value");
        }

    }
}