﻿using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System.IO;

namespace Levi9.NetSel.Elements
{
    public class FileUpload : BasePage
    {
        public FileUpload(IWebDriver webDriver) : base(webDriver) { }
      
		public void selectFile(string xpath, string filePath)
        {
            string fullPath = Path.GetFullPath(filePath);
            ((IJavaScriptExecutor)Driver).ExecuteScript("var element = document.evaluate('" + xpath + "', document, null, 9, null).singleNodeValue;");
            Driver.FindElement(By.XPath(xpath)).SendKeys(fullPath);
        }

	}

}