﻿using OpenQA.Selenium;
using System;
using Levi9.NetSel.Pages;

namespace Levi9.NetSel.Elements
{
    public class RadioButton
    {
        readonly IWebElement webElement;

        public RadioButton(IWebElement webElement)
        {
            this.webElement = webElement;

        }

        public void SelectValue()
        {
            webElement.Click();
        }

        public string GetValue()
        {
           return webElement.GetAttribute("value");
        }

        public Boolean IsSelected()
        {
            return webElement.Selected;
        }

        public void IterateRadioButtons(IWebDriver driver, By by, string value)
        {
            
            foreach (IWebElement rb in driver.FindElements(by))
            {
                if (rb.GetAttribute("value").Equals(value))
                {
                    rb.Click();
                }
            }
        }

    }
}