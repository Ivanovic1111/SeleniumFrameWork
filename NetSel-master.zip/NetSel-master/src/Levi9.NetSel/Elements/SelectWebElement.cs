﻿using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;

namespace Levi9.NetSel.Elements
{
    public class SelectWebElement
    {
        readonly IWebElement webElement;

        public SelectWebElement(IWebElement webElement)
        {
            this.webElement = webElement;
        }

        public void SelectByText(string value)
        {
            SelectElement select = new SelectElement(webElement);
            select.SelectByText(value);
        }

        public void SelectByValue(string value)
        {
            SelectElement select = new SelectElement(webElement);
            select.SelectByValue(value);
        }

        public void SelectMultipleValues(List<string> values)
        {
            SelectElement select = new SelectElement(webElement);

            foreach (string value in values)
            {
                select.SelectByValue(value);
            }
            
        }

        public void DeselectByText(string text)
        {
            SelectElement select = new SelectElement(webElement);
            select.DeselectByText(text);

        }

        public void DeselectAll()
        {
            SelectElement select = new SelectElement(webElement);
            select.DeselectAll();

        }

    }
}