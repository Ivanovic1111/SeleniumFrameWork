﻿using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Levi9.NetSel.Elements
{
    public class Table
    {
        readonly IWebElement webElement;

        public Table(IWebElement webElement)
        {
            this.webElement = webElement;
           
        }

        public IWebElement GetCellByContent(String content)
        {
            return webElement.FindElement(By.XPath("//td[contains(.,'" + content + "')]"));
        }

        public String GetCellByLocator(By locator)
        {
            return webElement.FindElement(locator).Text;
        }

        public IList GetElementsByRow()
        {
            IList<IWebElement> rows = webElement.FindElements(By.TagName("tr"));
            List<string> elements = new List<string>();
            foreach (var row in rows)
            {
                elements.Add(row.Text);
            }
            return elements;
        }

        public IList GetHeaders()
        {
            IList<IWebElement> columns = webElement.FindElements(By.TagName("th"));
            List<string> elements = new List<string>();
            foreach (var column in columns)
            {
                elements.Add(column.Text);
            }
            return elements;
        }

        public int GetRowSize()
        {
            IList<IWebElement> rows = webElement.FindElements(By.TagName("tr"));
            return rows.Count;
        }

        public int GetColumnSize()
        {
            IList<IWebElement> column = webElement.FindElements(By.TagName("th"));
            return column.Count;
        }
    }
}
