﻿using Levi9.NetSel.Pages;
using OpenQA.Selenium;

namespace Levi9.NetSel.Elements
{
    public class ClickableElements
    { 

        readonly IWebElement webElement;

        public ClickableElements(IWebElement webElement)
        {
           this.webElement = webElement;
        }

        public string GetAttribute(By by, string attribute)
        {
            return webElement.GetAttribute(attribute);
        }

        public string GetAttribute(string attribute)
        {
            return webElement.GetAttribute(attribute);
        }

        public void Click()
        {
            webElement.Click();
        }

        public bool IsDisplayed()
        {
            return webElement.Displayed;
        }

        public bool IsEnabled()
        {
            return webElement.Enabled;
        }
    }
}
