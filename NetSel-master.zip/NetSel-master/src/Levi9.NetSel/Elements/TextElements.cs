﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Levi9.NetSel.Pages;
using Levi9.NetSel.Elements;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Drawing;

namespace Levi9.NetSel.Elements
{
    public class TextElements
    {
        readonly IWebElement webElement;


        public TextElements(IWebElement webElement)
        {
            this.webElement = webElement;

        }

        //use if element has value set to return element's text
        public string getValue()
        {

            return webElement.GetAttribute("value");
        }

        //use to get displayed text of element
        public string getText()
        {
            return webElement.Text;

        }


    }
}
