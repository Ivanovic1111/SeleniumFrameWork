﻿using Levi9.NetSel.Pages;
using OpenQA.Selenium;
using System;

namespace Levi9.NetSel.Elements
{
    public class InputElements
    {
        readonly IWebElement webElement;

        public InputElements(IWebElement webElement)
        {
            this.webElement = webElement;
           
        }

        public void SendKeys(String keys)
        {
            ClearField();
            webElement.SendKeys(keys);
        }

        public void ClearField()
        {
            webElement.Clear();
        }

        public string GetAttribute(String attribute)
        {
            return webElement.GetAttribute(attribute);
        }

        public void FocusElement(IWebDriver driver)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].focus();", webElement);
        }

        public void FillHiddenField(IWebDriver driver, string hiddenValue)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].value='" + hiddenValue + "';", webElement);
        }

    }
}
