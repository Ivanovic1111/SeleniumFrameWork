﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Collections.Generic;

namespace Levi9.NetSel.Helpers
{
    public class DatabaseHelper
    {
        private static string CONNECTION_STRING;
        //private static readonly string CONNECTION_STRING;

       
        public DatabaseHelper(string connectionString)
        {
            CONNECTION_STRING =  ConfigurationManager.ConnectionStrings[connectionString].ConnectionString;
        }

        public SqlConnection createConnection()
        {
            return new SqlConnection(CONNECTION_STRING);
        }

        public SqlCommand createSelectCommand(SqlConnection conn, string fieldList, string table, params SqlParameter[] parameters)
        {
            var select = createSelectSQL(fieldList, table, parameters);
            SqlCommand comm = new SqlCommand(select, conn);
            if (parameters != null && parameters.Length > 0)
            {
                foreach (SqlParameter param in parameters)
                {
                    comm.Parameters.Add(param);
                }
            }
            return comm;
        }

        public string createSelectSQL(string fieldList, string table, params SqlParameter[] parameters)
        {
            StringBuilder sb = new StringBuilder();
            string select = String.Format("SELECT {0} FROM {1}", fieldList, table);
            sb.Append(select);
            if (parameters != null && parameters.Length > 0)
            {
                sb.Append(" WHERE");
                Boolean first = true;
                foreach (SqlParameter param in parameters)
                {
                    if (first)
                    {
                        first = false;
                    }
                    else
                    {
                        sb.Append(" ");
                        sb.Append("AND");
                    }
                    sb.Append(" ");
                    sb.Append(param.ParameterName.Substring(1));
                    sb.Append("=");
                    sb.Append(param.ParameterName);
                }
            }
            return sb.ToString();
        }

        public string queryForSingleResultAsString(string query)
        {
            string result = null;

            using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
            {
                using (SqlCommand comm = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    result = dr.GetString(0);
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }

            return result;
        }


        public int queryForSingleResultAsInteger(string query)
        {
            int result = 0;

            using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
            {
                using (SqlCommand comm = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    try
                                    {
                                        result = Int32.Parse(dr.GetString(0));
                                    }
                                    catch (FormatException e)
                                    {
                                        Console.WriteLine(e.Message);
                                    }

                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }

            return result;
        }

        public List<string> queryForListOfResults(string query)
        {
            List<string> resultList = new List<string>();
            using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
            {
                using (SqlCommand comm = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    resultList.Add(dr.GetString(0));
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }
            return resultList;

        }

        public long queryForSingleResultAsLong(string query)
        {
            long result = 0;

            using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
            {
                using (SqlCommand comm = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    try
                                    {
                                        result = long.Parse(dr.GetString(0));
                                    }
                                    catch (FormatException e)
                                    {
                                        Console.WriteLine(e.Message);
                                    }

                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }

            return result;
        }

        public DateTime queryForSingleResultAsDate(string query)
        {
            DateTime result = new DateTime();

            using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
            {
                using (SqlCommand comm = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader dr = comm.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    try
                                    {
                                        result = DateTime.Parse(dr.GetString(0));
                                    }
                                    catch (FormatException e)
                                    {
                                        Console.WriteLine(e.Message);
                                    }

                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }

            return result;
        }

        public void executeQuery(string query)
        {
            using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
            {
                using (SqlCommand comm = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataReader dr = comm.ExecuteReader();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }
        }

        public void executeMultipleQueriesFromFile(string filepath)
        {
            //add validation for file !empty
            string query = FileHandler.ReadAllFromFile(filepath);
            using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
            {
                using (SqlCommand comm = new SqlCommand(query, conn))
                {

                    try
                    {
                        conn.Open();
                        SqlDataReader dr = comm.ExecuteReader();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                }
            }
        }
    }
}
