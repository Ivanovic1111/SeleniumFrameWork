﻿using System;
using System.Text;
using System.IO;

namespace Levi9.NetSel.Helpers
{
    public class FileHandler
    {

        public static string ReadAllFromFile(string filePath)
        {
            string outputText = "";
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File does not exist!");
            }
            else
            {
                outputText = File.ReadAllText(filePath);
            }
            return outputText;
        }

      /*  public void CreateFile(string path)
        {
            if (!File.Exists(path))
            {
                FileStream fs = File.Create(path);
                Console.WriteLine("File created!!");
                
            }
            else
            {
                Console.WriteLine("File already exists!");
            }

        }


        public void WriteTextToFile(string path, string text)
        {
            if (!File.Exists(path))
            {
                Console.WriteLine("File does not exists!!");
            }
            else
            {
                File.WriteAllText(path, text); 
            }
        }
        */
    }

}
