﻿using System.Linq;
using System.Xml.Linq;

namespace Levi9.NetSel.Pages
{
    public class XmlReader
    {

        
        public string GetValueByKey(string key, string xmlName)
        {
            XDocument doc = XDocument.Load(xmlName);
            XElement elm = doc.Root.Elements().FirstOrDefault(e => e.Attribute("key") != null && e.Attribute("key").Value == key);
            return elm.Attribute("value").Value;
        }
    }
}
