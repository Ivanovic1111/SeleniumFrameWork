﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Text;

namespace Levi9.NetSel.Helpers
{
    /// <summary>
    /// Helper class that contains static methods for generating random data
    /// </summary>
    public static class RandomDataGenerator
    {
        private const string DigitCharacters = "0123456789";
        private const string LetterCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        private const string SpecialCharacters = ".,:;!?'-_+=|/()[]{}@#$%&*<>^~\"\\";

        /// <summary>
        /// Generate random string with fixed length from input string data
        /// </summary>
        /// <param name="input">Input string data</param>
        /// <param name="length">Length of randomly generated string</param>
        /// <returns>String with fixed length from randomly generated input string data</returns>
        public static string RandomStringFromInput(string input, int length)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var result = new StringBuilder(length);
            for (var i = 0; i < length; i++)
            {
                result.Append(input[random.Next(input.Length)]);
            }
            return result.ToString();
        }

        /// <summary>
        /// Generate random string of letters and numerical digits with fixed length
        /// </summary>
        /// <param name="length">Length of randomly generated string</param>
        /// <returns>String with fixed length from randomly generated letters and numerical digits</returns>
        public static string RandomString(int length)
        {
            var result = RandomStringFromInput(DigitCharacters + LetterCharacters, length);
            return result;
        }

        /// <summary>
        /// Generate random string of letters with fixed length
        /// </summary>
        /// <param name="length">Length of randomly generated string</param>
        /// <returns>String with fixed length from randomly generated letters</returns>
        public static string RandomLetterString(int length)
        {
            var result = RandomStringFromInput(LetterCharacters, length);
            return result;
        }

        /// <summary>
        /// Generate random string of numerical digits with fixed length
        /// </summary>
        /// <param name="length">Length of randomly generated string</param>
        /// <returns>String with fixed length from randomly generated numerical digits</returns>
        public static string RandomDigitString(int length)
        {
            var result = RandomStringFromInput(DigitCharacters, length);
            return result;
        }

        /// <summary>
        /// Generate random string of numerical digits with fixed length and without leading zero
        /// </summary>
        /// <param name="length">Length of randomly generated string</param>
        /// <returns>String with fixed length from randomly generated numerical digits without leading zero</returns>
        public static string RandomNumberString(int length)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var result = new StringBuilder(length);
            result.Append(random.Next(1, 10));
            for (var i = 0; i < length - 1; i++)
            {
                result.Append(random.Next(10));
            }
            return result.ToString();
        }

        /// <summary>
        /// Generate random string of ASCII special characters with fixed length
        /// </summary>
        /// <param name="length">Length of randomly generated string</param>
        /// <returns>String with fixed length from randomly generated ASCII special characters</returns>
        public static string RandomSpecialCharacterString(int length)
        {
            var result = RandomStringFromInput(SpecialCharacters, length);
            return result;
        }

        /// <summary>
        /// Generate random string with length within [minimum, maximum) range
        /// </summary>
        /// <param name="minimum">Minimum value of range</param>
        /// <param name="maximum">Maximum value of range</param>
        /// <returns>String with length within [minimum, maximum) range from randomly generated letters and numerical digits</returns>
        public static string RandomStringLengthWithinRange(int minimum, int maximum)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var length = random.Next(minimum, maximum);
            var result = RandomString(length);
            return result;
        }

        /// <summary>
        /// Generate random string from input string List data
        /// </summary>
        /// <param name="list">Input string List data</param>
        /// <returns>String randomly selected from input string List data</returns>
        public static string RandomStringFromList(List<string> list)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var index = random.Next(list.Count);
            var result = list[index];
            return result;
        }

        /// <summary>
        /// Generate random email address with fixed length user name and domain name
        /// </summary>
        /// <param name="length">Length of randomly generated string for both user name and domain name</param>
        /// <returns>String for email address with fixed length user name and domain name from randomly generated letters and numerical digits</returns>
        public static string RandomEmailAddress(int length)
        {
            var result = RandomString(length).ToLower() + "@" + RandomLetterString(length).ToLower() + ".com";
            return result;
        }

        /// <summary>
        /// Generate random web address with fixed length domain name
        /// </summary>
        /// <param name="length">Length of randomly generated string for domain name</param>
        /// <returns>String for web address with fixed length domain name from randomly generated letters and numerical digits</returns>
        public static string RandomWebAddress(int length)
        {
            var result = "www." + RandomString(length).ToLower() + ".com";
            return result;
        }

        /// <summary>
        /// Generate random (first/last) name with fixed length
        /// </summary>
        /// <param name="length">Length of randomly generated string for name</param>
        /// <returns>String for name with fixed length from randomly generated letters</returns>
        public static string RandomName(int length)
        {
            var randomLetterString = RandomLetterString(length);
            var result = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(randomLetterString);
            return result;
        }

        /// <summary>
        /// Generate random bool
        /// </summary>
        /// <returns>Randomly generated bool</returns>
        public static bool RandomBool()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var result = random.NextDouble() > 0.5;
            return result;
        }

        /// <summary>
        /// Generate random int within [minimum, maximum) range
        /// </summary>
        /// <param name="minimum">Minimum value of range</param>
        /// <param name="maximum">Maximum value of range</param>
        /// <returns>Int with random value within [minimum, maximum) range</returns>
        public static int RandomIntegerWithinRange(int minimum, int maximum)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var result = random.Next(minimum, maximum);
            return result;
        }

        /// <summary>
        /// Generate random positive int with fixed length
        /// </summary>
        /// <param name="length">Number of numerical digits in randomly generated int</param>
        /// <returns>Positive int with fixed number of randomly generated numerical digits</returns>
        public static int RandomPositiveInteger(int length)
        {
            var randomNumberString = RandomNumberString(length);
            var result = int.Parse(randomNumberString);
            return result;
        }

        /// <summary>
        /// Generate random negative int with fixed length
        /// </summary>
        /// <param name="length">Number of numerical digits in randomly generated int</param>
        /// <returns>Negative int with fixed number of randomly generated numerical digits</returns>
        public static int RandomNegativeInteger(int length)
        {
            var randomPositiveInteger = RandomPositiveInteger(length);
            var result = randomPositiveInteger * (-1);
            return result;
        }

        /// <summary>
        /// Generate random int with fixed length
        /// </summary>
        /// <param name="length">Number of numerical digits in randomly generated int</param>
        /// <returns>Int with fixed number of randomly generated numerical digits</returns>
        public static int RandomInteger(int length)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var randomPositiveInteger = RandomPositiveInteger(length);
            var result = randomPositiveInteger * (random.Next(0, 2) * 2 - 1);
            return result;
        }

        /// <summary>
        /// Generate random array with fixed length of int within [minimum, maximum) range 
        /// </summary>
        /// <param name="minimum">Minimum value of range</param>
        /// <param name="maximum">Maximum value of range</param>
        /// <param name="length">Length of randomly generated array</param>
        /// <returns>Array with fixed length of ints with random value within [minimum, maximum) range</returns>
        public static int[] RandomIntegerArray(int minimum, int maximum, int length)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var result = new int[length];
            for (var i = 0; i < result.Length; i++)
            {
                result[i] = random.Next(minimum, maximum);
            }
            return result;
        }

        /// <summary>
        /// Generate random double within [minimum, maximum) range
        /// </summary>
        /// <param name="minimum">Minimum value of range</param>
        /// <param name="maximum">Maximum value of range</param>
        /// <returns>Double with random value within [minimum, maximum) range</returns>
        public static double RandomDoubleWithinRange(int minimum, int maximum)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var result = random.NextDouble() * (maximum - minimum) + minimum;
            return result;
        }

        /// <summary>
        /// Generate random double
        /// </summary>
        /// <returns>Randomly generated double</returns>
        public static double RandomDouble()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var randomInteger = random.Next(1000);
            var result = random.NextDouble() * randomInteger;
            return result;
        }
        
        /// <summary>
        /// Generate random DateTime within [start, end) date range
        /// </summary>
        /// <param name="start">Start date of range</param>
        /// <param name="end">End date of range</param>
        /// <returns>DateTime with random value within [start, end) date range</returns>
        public static DateTime RandomDateTimeWithinRange(DateTime start, DateTime end)
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var range = end - start;
            var randomTimeSpan = new TimeSpan((long)(random.NextDouble() * range.Ticks));
            var result = start + randomTimeSpan;
            return result;
        }
        
        /// <summary>
        /// Generate random DateTime without range
        /// </summary>
        /// <returns>Randomly generated DateTime without range</returns>
        public static DateTime RandomDateTime()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var start = DateTime.Now.AddYears(random.Next(100) * (-1));
            var end = DateTime.Now.AddYears(random.Next(100));
            var result = RandomDateTimeWithinRange(start, end);
            return result;
        }

        /// <summary>
        /// Generate random DateTime before current date and time
        /// </summary>
        /// <returns>Randomly generated DateTime before current date and time</returns>
        public static DateTime RandomDateTimeBeforeCurrent()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var start = DateTime.Now.AddYears(random.Next(100) * (-1));
            var result = RandomDateTimeWithinRange(start, DateTime.Now);
            return result;
        }

        /// <summary>
        /// Generate random DateTime after current date and time
        /// </summary>
        /// <returns>Randomly generated DateTime after current date and time</returns>
        public static DateTime RandomDateTimeAfterCurrent()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var end = DateTime.Now.AddYears(random.Next(100));
            var result = RandomDateTimeWithinRange(DateTime.Now, end);
            return result;
        }

        /// <summary>
        /// Generate random DateTime today
        /// </summary>
        /// <returns>Randomly generated DateTime today</returns>
        public static DateTime RandomDateTimeToday()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var minuteCount = random.Next(1440);
            var result = DateTime.Today.AddMinutes(minuteCount);
            return result;
        }

        /// <summary>
        /// Generate random DateTime before current date and time within last century
        /// </summary>
        /// <returns>Randomly generated DateTime before current date and time within last century</returns>
        public static DateTime RandomDateTimeLastCentury()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var start = DateTime.Now.AddYears(-100);
            var result = RandomDateTimeWithinRange(start, DateTime.Now);
            return result;
        }

        /// <summary>
        /// Generate random ARGB Color
        /// </summary>
        /// <returns>Randomly generated ARGB Color</returns>
        public static Color RandomARGBColor()
        {
            var random = new Random(Guid.NewGuid().GetHashCode());
            var colorNames = (KnownColor[])Enum.GetValues(typeof(KnownColor));
            var randomColor = colorNames[random.Next(colorNames.Length)];
            var result = Color.FromKnownColor(randomColor);
            return result;
        }
    }
}