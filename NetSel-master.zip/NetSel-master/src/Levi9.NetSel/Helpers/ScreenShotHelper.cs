﻿using OpenQA.Selenium;
using System;
using System.Drawing.Imaging;

namespace Levi9.NetSel.Pages
{
    public class ScreenShotHelper
    {
        public static void captureScreenshot(IWebDriver driver, String filename)
        {
           
            String path = "../../resources/screenshot/";
            ITakesScreenshot screenshotDriver = driver as ITakesScreenshot;
            Screenshot screenshot = screenshotDriver.GetScreenshot();

            screenshot.SaveAsFile(path+filename, ImageFormat.Png);
        }
    }
}
