﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Levi9.NetSel.Helpers
{
    /// <summary>
    /// Wait helper class that contains static waiting methods
    /// </summary>
    public static class WaitHelper
    {
        /// <summary>
        /// Wait until element is present on the DOM or timeout period expires
        /// </summary>
        /// <param name="driver">WebDriver Instance<see cref="IWebDriver"/></param>
        /// <param name="locator">Locator of element<see cref="By"/></param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if element is found within given time, otherwise false</returns>
        public static bool WaitUntilElementExists(IWebDriver driver, By locator, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.ElementExists(locator));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until element is present on DOM and visible on page or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance<see cref="IWebDriver"/></param>
        /// <param name="locator">Locator of element<see cref="By"/></param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if element becomes visible within given time, otherwise false</returns>
        public static bool WaitUntilElementIsVisible(IWebDriver driver, By locator, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.ElementIsVisible(locator));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until element is clickable (visible and enabled) or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance<see cref="IWebDriver"/></param>
        /// <param name="locator">Locator of element<see cref="By"/></param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if element becomes clickable within given time, otherwise false</returns>
        public static bool WaitUntilElementIsClickable(IWebDriver driver, By locator, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.ElementToBeClickable(locator));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until element exists on the DOM and is clickable (visible and enabled) or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance<see cref="IWebDriver"/></param>
        /// <param name="locator">Locator of element<see cref="By"/></param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if element becomes found and is clickable within given time, otherwise false</returns>
        public static bool WaitUntilElementExistsAndIsClickable(IWebDriver driver, By locator, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.ElementExists(locator));
                driverWait.Until(ExpectedConditions.ElementToBeClickable(locator));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until element is either invisible or not present on the DOM or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance<see cref="IWebDriver"/></param>
        /// <param name="locator">Locator of element to wait for<see cref="By"/></param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if element becomes invisible within given time, otherwise false</returns>
        public static bool WaitUntilElementIsNotVisible(IWebDriver driver, By locator, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.InvisibilityOfElementLocated(locator));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until element becomes stale (not attached to DOM) or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance<see cref="IWebDriver"/></param>
        /// <param name="elemenet">Element to wait for<see cref="IWebElement"/></param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if element becomes stale within given time, otherwise false</returns>
        public static bool WaitUntilElementIsStale(IWebDriver driver, IWebElement element, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.StalenessOf(element));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until all provided elements are present or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance <see cref="IWebDriver"/></param>
        /// <param name="locator">locator of element that to wait for <see cref="By"/></param>
        /// <param name="timeOutInSeconds">time after what waiting for is ended</param>
        /// <returns>true if all elements are found within given time, otherwise false</returns>
        public static bool WaitUntilElementsArePresent(IWebDriver driver, By locator, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(locator));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until text is present for the provided element or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance <see cref="IWebDriver"/></param>
        /// <param name="locator">Locator of element that to wait for <see cref="By"/></param>
        /// <param name="text">Text that is to be present in element</param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if text becomes present in element within given time, otherwise false</returns>
        public static bool WaitUntilTextIsPresentInElement(IWebDriver driver, By locator, string text, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.TextToBePresentInElementLocated(locator, text));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until text is present in value property of the provided element or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance <see cref="IWebDriver"/></param>
        /// <param name="locator">Locator of element that to wait for <see cref="By"/></param>
        /// <param name="text">Text that is to be present in element value</param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if text becomes present in elements value within given time, otherwise false</returns>
        public static bool WaitUntilTextIsPresentInElementValue(IWebDriver driver, By locator, string text, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.TextToBePresentInElementValue(locator, text));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until title of the page is as provided or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance <see cref="IWebDriver"/></param>
        /// <param name="title">Title of the page</param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if title of the page is found within given time, otherwise false</returns>
        public static bool WaitUntilTitleIs(IWebDriver driver, string title, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.TitleIs(title));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until title of the page contains the text or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance <see cref="IWebDriver"/></param>
        /// <param name="text">Text contained in title of the page</param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if title of the page contains given text within given time, otherwise false</returns>
        public static bool WaitUntilTitleContains(IWebDriver driver, string text, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.TitleContains(text));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until current URL is as provided or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance <see cref="IWebDriver"/></param>
        /// <param name="url">URL of the page</param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if URL is found within given time, otherwise false</returns>
        public static bool WaitUntilUrlIs(IWebDriver driver, string url, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.UrlToBe(url));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait until current URL contains the text or time out expires
        /// </summary>
        /// <param name="driver">WebDriver Instance <see cref="IWebDriver"/></param>
        /// <param name="text">Text contained in URL</param>
        /// <param name="timeOutInSeconds">Time after what waiting for is ended</param>
        /// <returns>true if URL contains given text within given time, otherwise false</returns>
        public static bool WaitUntilUrlContains(IWebDriver driver, string text, long timeOutInSeconds)
        {
            WebDriverWait driverWait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeOutInSeconds));
            try
            {
                driverWait.Until(ExpectedConditions.UrlContains(text));
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Wait for defined time
        /// </summary>
        /// <param name="seconds">Number of seconds to wait for</param>
        public static void WaitAdditional(double seconds)
        {
            if (seconds > 0)
            {
                int milliseconds = (int)(seconds * 1000);

                try
                {
                    Thread.Sleep(milliseconds);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    Thread.CurrentThread.Interrupt();
                    throw new WebDriverException();
                }
            }
        }
    }
}