﻿using System;
using System.Text;

namespace Levi9.NetSel.Helpers
{
    /// <summary>
    /// Helper class that contains static methods for generating random BSN, BBAN, IBAN
    /// </summary>
    public static class RandomAccountNumber
    {
        /// <summary>
        /// Generate random 9 digit BSN number for Netherlands. More info: https://en.wikipedia.org/wiki/National_identification_number#Netherlands
        /// </summary>
        public static string GenerateRandomBsnNumberNL()
        {
            Random random = new Random(Guid.NewGuid().GetHashCode());
            int[] integers = new int[9];
            for (int i = 0; i < 7; i++)
            {
                integers[i] = random.Next(9);
            }
            integers[7] = 0;
            integers[8] = 0;
            int first7 = 0;
            for (int i = 0; i < 7; i++)
            {
                first7 = first7 + (9 - i) * integers[i];
            }
            int mod11 = first7 % 11;
            switch (mod11)
            {
                case 0:
                    integers[7] = 0;
                    integers[8] = 0;
                    break;
                case 1:
                    integers[7] = 5;
                    integers[8] = 0;
                    break;
                case 2:
                    integers[7] = 5;
                    integers[8] = 1;
                    break;
                case 3:
                    integers[7] = 4;
                    integers[8] = 0;
                    break;
                case 4:
                    integers[7] = 4;
                    integers[8] = 1;
                    break;
                case 5:
                    integers[7] = 3;
                    integers[8] = 0;
                    break;
                case 6:
                    integers[7] = 3;
                    integers[8] = 1;
                    break;
                case 7:
                    integers[7] = 2;
                    integers[8] = 0;
                    break;
                case 8:
                    integers[7] = 2;
                    integers[8] = 1;
                    break;
                case 9:
                    integers[7] = 1;
                    integers[8] = 0;
                    break;
                case 10:
                    integers[7] = 1;
                    integers[8] = 1;
                    break;
            }
            string uniqueBsn = string.Join("", integers);
            return uniqueBsn;
        }

        /// <summary>
        /// Generate random 10 digit Account number for Netherlands. In NL this number should fit 11-check.
        /// </summary>
        public static int[] GenerateRandomAccountNumberNL()
        {
            Random random = new Random(Guid.NewGuid().GetHashCode());
            int[] integers = new int[10];
            for (int i = 0; i < 8; i++)
            {
                integers[i] = random.Next(9);
            }
            integers[8] = 0;
            integers[9] = 0;
            int first8 = 0;
            for (int i = 0; i < 8; i++)
            {
                first8 = first8 + (10 - i) * integers[i];
            }
            int mod11 = first8 % 11;
            switch (mod11)
            {
                case 0:
                    integers[8] = 4;
                    integers[9] = 3;
                    break;
                case 1:
                    integers[8] = 4;
                    integers[9] = 2;
                    break;
                case 2:
                    integers[8] = 4;
                    integers[9] = 1;
                    break;
                case 3:
                    integers[8] = 4;
                    integers[9] = 0;
                    break;
                case 4:
                    integers[8] = 3;
                    integers[9] = 1;
                    break;
                case 5:
                    integers[8] = 3;
                    integers[9] = 0;
                    break;
                case 6:
                    integers[8] = 2;
                    integers[9] = 1;
                    break;
                case 7:
                    integers[8] = 2;
                    integers[9] = 0;
                    break;
                case 8:
                    integers[8] = 1;
                    integers[9] = 1;
                    break;
                case 9:
                    integers[8] = 1;
                    integers[9] = 0;
                    break;
                case 10:
                    integers[8] = 0;
                    integers[9] = 1;
                    break;
            }
            return integers;
        }

        /// <summary>
        /// Generate random 18 digit IBAN for Netherlands. BIC can only have 4 letters.
        /// </summary>
        public static string GenerateRandomIbanNL(string bic)
        {
            byte[] bicBytes = Encoding.ASCII.GetBytes(bic);
            int[] integers = new int[18];
            int[] accountNo = GenerateRandomAccountNumberNL();
            for (int i = 0; i < 4; i++)
            {
                integers[i] = Convert.ToInt16(bicBytes[i]) - 55;
            }
            for (int j = 4; j < 14; j++)
            {
                integers[j] = accountNo[j - 4];
            }
            integers[14] = Convert.ToInt16(Encoding.ASCII.GetBytes("N")[0]) - 55;
            integers[15] = Convert.ToInt16(Encoding.ASCII.GetBytes("L")[0]) - 55;
            integers[16] = 0;
            integers[17] = 0;
            string invertedIban = string.Join("", integers);
            decimal decimalIban = Convert.ToDecimal(invertedIban);
            int mod11 = Convert.ToInt16(decimalIban % 97);
            int security = 97 + 1 - mod11;
            string finalSecurity = string.Empty;
            if (security < 10)
            {
                finalSecurity = "0" + security.ToString();
            }
            else
            {
                finalSecurity = security.ToString();
            }
            string iban = "NL" + finalSecurity + bic + string.Join("", accountNo);
            return iban;
        }
    }
}