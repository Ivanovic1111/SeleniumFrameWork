﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;


namespace Levi9.NetSel.Helpers
{
    public class CSVReader { 

  
        //string file = "add_string_path";
        //string delimiter = ",";

        public static List<string[]> parseCSV(string file, string delimiter)
        {
            var parsedData = new List<string[]>();
            string[] fields;

            try
            {
                var parser = new TextFieldParser(@file);

                parser.TextFieldType = FieldType.Delimited;
                parser.SetDelimiters(delimiter);

                while (!parser.EndOfData)
                {
                    fields = parser.ReadFields();
                    parsedData.Add(fields);

                }
                parser.Close();
            }
            catch (Exception e)
            {
                throw e;
            }

            return parsedData;
        }
    }
}
