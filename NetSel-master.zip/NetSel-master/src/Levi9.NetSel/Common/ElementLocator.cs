﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Levi9.NetSel.Common
{
    public class ElementLocator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ElementLocator"/> class.
        /// </summary>
        /// <example>How we define locator: <code>
        /// private readonly ElementLocator searchTextbox = new ElementLocator(Locator.Id, "SearchTextBoxId");
        /// </code> </example>
        /// <param name="kind">The locator type.</param>
        /// <param name="value">The locator value.</param>
        public ElementLocator(Locator type, string value)
        {
            this.Type = type;
            this.Value = value;
        }

        public Locator Type { get; private set; }
        public string Value { get; private set; }
    }
}
