﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Levi9.NetSel.BaseTest
{
    public enum BrowserType
    {
        /// <summary>
        /// Firefox browser
        /// </summary>
        Firefox,

        /// <summary>
        /// InternetExplorer browser
        /// </summary>
        InternetExplorer,

        /// <summary>
        /// Chrome browser
        /// </summary>
        Chrome,

        /// <summary>
        /// PhantomJS 
        /// </summary>
        PhantomJS,


        /// <summary>
        /// Not supported browser
        /// </summary>
        None
    }
}
