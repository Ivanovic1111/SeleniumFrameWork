﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
using OpenQA.Selenium.Remote;
using System.Threading;
using System.Configuration;
using System.Globalization;
using Levi9.NetSel.BaseTest;
using OpenQA.Selenium.PhantomJS;

namespace Levi9.NetSel.Test
{

    public class BaseTest
    {
        ThreadLocal<IWebDriver> driver;
      
	  
	  public void InitializeLocalDriver()
        {
            switch (TestBrowser)
            {
                case BrowserType.Firefox:
                    driver = new ThreadLocal<IWebDriver>(() => {return new FirefoxDriver(DesiredCapabilities.Firefox()); });
                    break;
                
                case BrowserType.InternetExplorer:
                    driver = new ThreadLocal<IWebDriver>(() =>{return new InternetExplorerDriver(AddInternetExplorerOptions());});
                    break;

                case BrowserType.Chrome:
                    driver = new ThreadLocal<IWebDriver>(() => { return new ChromeDriver();});
                    break;

                case BrowserType.PhantomJS:
                    driver = new ThreadLocal<IWebDriver>(() => { return new PhantomJSDriver(); });
                    break;
                    
                default:
                    throw new NotSupportedException(
                        string.Format(CultureInfo.CurrentCulture, "Driver {0} is not supported", TestBrowser));
            }
        }

        public void InitializeDriver()
        {
            if (IsRemote)
            {
                switch (TestBrowser)
                {
                    case BrowserType.Firefox:
                        InitializeRemoteDriver(AddFirefoxCapabilities());
                        break;

                    case BrowserType.InternetExplorer:
                        InitializeRemoteDriver(AddIExplorerCapabilities());
                        break;

                    case BrowserType.Chrome:
                        InitializeRemoteDriver(DesiredCapabilities.Chrome());
                        break;

                    default:
                        throw new NotSupportedException(
                            string.Format(CultureInfo.CurrentCulture, "Driver {0} is not supported", TestBrowser));
                }
            }
            else
            {
                InitializeLocalDriver();
            }

        }

        public void InitializeDriver(DesiredCapabilities capabilities)
        {
            if (IsRemote)
            {
                InitializeRemoteDriver(capabilities);
            }
            else
            {
                InitializeLocalDriver();
            }
        }

        private void InitializeRemoteDriver(DesiredCapabilities capabilities)
        {
            driver = new ThreadLocal<IWebDriver>(() =>
            {
                return new RemoteWebDriver(new Uri(RemoteURL), capabilities);
            });
        }

       

        public DesiredCapabilities AddFirefoxCapabilities()
        {
            DesiredCapabilities desiredCap = DesiredCapabilities.Firefox();
            FirefoxProfile firefoxProfile = new FirefoxProfile();

            //disable Flash in firefox
            firefoxProfile.SetPreference("plugin.state.flash", 0);
            desiredCap.SetCapability(FirefoxDriver.ProfileCapabilityName, firefoxProfile.ToBase64String());

            //enable live screencase
            desiredCap.SetCapability("browserstack.debug", "true");

            //enable video recording
            desiredCap.SetCapability("browserstack.video", "false");

            //download capabilities
            firefoxProfile.SetPreference("browser.download.folderList", 2);
            firefoxProfile.SetPreference("browser.download.manager.focusWhenStarting", false);
            firefoxProfile.SetPreference("browser.download.useDownloadDir", true);
            firefoxProfile.SetPreference("browser.helperApps.neverAsk.saveToDisk", 
                "application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
            // disable Firefox's built-in PDF viewer
            firefoxProfile.SetPreference("browser.helperApps.alwaysAsk.force", false);
            firefoxProfile.SetPreference("browser.download.manager.alertOnEXEOpen", false);
            firefoxProfile.SetPreference("browser.download.manager.closeWhenDone", true);
            firefoxProfile.SetPreference("browser.download.manager.showAlertOnComplete", false);
            firefoxProfile.SetPreference("browser.download.manager.useWindow", false);
          
            desiredCap.SetCapability(FirefoxDriver.ProfileCapabilityName, firefoxProfile.ToBase64String());
            return desiredCap;
        }

        public DesiredCapabilities AddIExplorerCapabilities()
        {
            DesiredCapabilities desiredCap = DesiredCapabilities.InternetExplorer();

            //Disable flash in Internet Explorer
            desiredCap.SetCapability("browserstack.ie.noFlash", "true");
            desiredCap.SetCapability("ignoreZoomSetting", true);
            desiredCap.SetCapability("unexpectedAlertBehaviour", "ignore");
            desiredCap.SetCapability("ie.ensureCleanSession", true);
            desiredCap.SetCapability(CapabilityType.AcceptSslCertificates, true);
            return desiredCap;
        }

        public InternetExplorerOptions AddInternetExplorerOptions()
        {
            return new InternetExplorerOptions
            {
                UnexpectedAlertBehavior = InternetExplorerUnexpectedAlertBehavior.Ignore,
                EnsureCleanSession = true,
                IgnoreZoomLevel = true,
            };
        }

        public IWebDriver Driver {
            get
            {
                if (driver?.Value == null )
                {
                   this.InitializeDriver(); 
                }
                return driver.Value;
            }
        }

        public void OpenPage(String url)
        {
            Driver.Navigate().GoToUrl(url);
        }

        public void MaximizeBrowser()
        {
            Driver.Manage().Window.Maximize();
        }

        public void Refresh()
        {
            Driver.Navigate().Refresh();
        }

        /// <summary>
        /// Gets the username.
        /// </summary>
        public static string Username
        {
            get { return ConfigurationManager.AppSettings["username"]; }
        }

        /// <summary>
        /// Gets the password.
        /// </summary>
        public static string Password
        {
            get { return ConfigurationManager.AppSettings["password"]; }
        }

        public static string RemoteURL
        {
            get { return ConfigurationManager.AppSettings["remoteUrl"]; }
        }

        public static bool UseDefaultFirefoxDriver
        {
            get
            {

                if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["UseDefaultFirefoxDriver"]))
                {
                    return false;
                }

                if (ConfigurationManager.AppSettings["UseDefaultFirefoxDriver"].ToLower(CultureInfo.CurrentCulture).Equals("true"))
                {
                    return true;
                }

                return false;
            }
        }

        public static bool IsRemote
        {
            get
            {
                if (ConfigurationManager.AppSettings["remote"].ToLower(CultureInfo.CurrentCulture).Equals("true"))
                {
                    return true;
                }

                return false;
            }
        }

        public static BrowserType TestBrowser
        {
            get
            {
                BrowserType browserType;
                bool supportedBrowser = Enum.TryParse(ConfigurationManager.AppSettings["browser"], out browserType);


                if (UseDefaultFirefoxDriver)
                {
                    return BrowserType.Firefox;
                }
                else
                if (supportedBrowser)
                {
                    return browserType;
                }

                return BrowserType.None;
            }
        }

        
    }
}
