﻿using OpenQA.Selenium;
using System.Collections.Generic;

namespace Levi9.NetSel.Pages
{
    public class BasePage
    {
        protected IWebDriver myDriver;
  
        public BasePage(IWebDriver myDriver)
        {
            this.myDriver = myDriver;
        }

        public IWebDriver Driver
        {
            get { return myDriver; }
        }

        public IWebElement GetElement(By by)
        {
            try
            {
                return Driver.FindElement(by);
            }
            catch
            {
                throw new NoSuchElementException("No element with locator: " + by);
            }
        }

        public ICollection<IWebElement> GetElements(By by)
        {
            try
            {
                return Driver.FindElements(by);
            }
            catch
            {
                throw new NoSuchElementException("No elements with locator: " + by);
            }
        }
    }
}
