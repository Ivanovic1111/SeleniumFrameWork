param (
    [Parameter(Mandatory=$true)][String] $inputfile,
    [Parameter(Mandatory=$true)][String] $outputfile
)

$reportUnit = ".\packages\ReportUnit.*\tools\ReportUnit.exe"
 
if (!(Test-Path $reportUnit))
{
    throw "reportunit.exe does not exist. Please check $reportUnit file."
}

if (!(Test-Path $outputfile))
{
    throw "outputfile does not exist."
}

if (!(Test-Path $inputfile))
{
    throw "inputfile does not exist."
}

 & $reportUnit $inputfile $outputfile